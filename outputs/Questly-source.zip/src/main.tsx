import React, { lazy, Suspense } from 'react';
import { createRoot } from 'react-dom/client';
import { supabaseConfigured } from './lib/config';
import './styles.css';

const DemoApp=lazy(()=>import('./Questly'));
const CloudApp=lazy(()=>import('./CloudApp'));
function Root(){return <React.StrictMode><Suspense fallback={<div className="cloud-loading">Loading Questly…</div>}>{supabaseConfigured?<CloudApp/>:<DemoApp/>}</Suspense></React.StrictMode>}
createRoot(document.getElementById('root')!).render(<Root/>);
